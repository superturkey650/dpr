const { handler } = require('./index.js');

const event = {
  imdbID: 'tt0068646',
  token: 'ar3hbp1i25',
};

handler(event);
